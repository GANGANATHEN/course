package core.strings;

public class Buff {
	public static void main(String[] args) {
		StringBuffer s1 = new StringBuffer("rajendran");
//		System.out.println(s1);
//		s1.append(23);
//		System.out.println(s1);
//		s1.delete(0,2);
//		System.out.println(s1);
//		s1.deleteCharAt(2);
//		System.out.println(s1);
		
//		s1.setCharAt(0, 'G');
//		System.out.println(s1);
		
		
		
		
		
		
		
	}

}
