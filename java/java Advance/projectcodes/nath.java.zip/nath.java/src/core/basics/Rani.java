package core.basics;

public class Rani {
	
//	Rani  m1() {
//		System.out.println("good");
//		return new Rani();
//	}
//	public static void main(String[] args) {
//		//Rani r = new Rani();
//		Rani r1= r.m1();
//	}

	
//	int a =28;
//	static void m2(Rani r) {
//		System.out.println(r.a);
//	}
//   Rani m2() {
//	   System.out.println("hii...");
//	   return new Rani();
//   }
	
	
	
	public static void main(String[] args) {
		
//		int a =3;
//		String s ="3";
//		String s1 = Integer.toString(a);
//		
//		System.out.println(s1==s);
//		System.out.println(s1.equals(s));
//		System.out.println();
//		
		for(int i =0; i>5;i++) {
			System.out.println(i);
		}
		
	}
	
	
	
	
	
}
