package core.basics;

public class K7 {

	static void m1() {
		
	}
	public static void main(String[] args) {
		
	System.out.println("java");
	//K7 k = new K7();
	System.out.println();
	//k.m1();
		
	}
}
