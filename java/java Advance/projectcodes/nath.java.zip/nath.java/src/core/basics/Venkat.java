package core.basics;

public class Venkat {

	void m2(int a,float d) {
		System.out.println(a);
		System.out.println(d);

	}
	public static void main(String[] args) {
		Venkat q = new Venkat();
		q.m2(50,2.5f);
		
	}
}
