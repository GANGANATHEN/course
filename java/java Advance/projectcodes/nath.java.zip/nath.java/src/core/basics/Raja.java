package core.basics;

public class Raja {

	void m1(float a) {
		System.out.println(a);
	}
	
	public static void main(String[] args) {
		Raja r = new Raja();
		r.m1( 5);
	}
	
}
