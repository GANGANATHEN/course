package Collectionsss;

import java.util.Comparator;

public class Sortbyname implements Comparator {

	@Override
	public int compare(Sportsman o1, Sportsman o2) {
		
		return o1.name CompareTo(o2.name);
	}

	private void CompareTo(String name) {
		// TODO Auto-generated method stub
		
	}

}
