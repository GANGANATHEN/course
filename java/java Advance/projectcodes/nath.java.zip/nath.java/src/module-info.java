/**
 * 
 */
/**
 * 
 */
module nath.java {
	requires java.sql;
}