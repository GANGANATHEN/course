package com.demo;

public class Rectangle extends Shape {

	Rectangle(int l, int b) {
		super(l, b);
	}
}
