package com.demo;

public class Shapeimpl {

	public static void main(String[] args) {
	 Square s = new Square(1,2,3,4);
		s.mul();
	}
	
	

}
