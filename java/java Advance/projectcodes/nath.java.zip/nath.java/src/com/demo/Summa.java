package com.demo;

public class Summa {

}
