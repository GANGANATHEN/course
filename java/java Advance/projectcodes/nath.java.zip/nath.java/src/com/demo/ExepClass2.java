package com.demo;

public class ExepClass2 {

	public static void main(String[] args) {
		String s = "raja";
		for(int i =0;i<s.length();i++) {
			System.out.println(s.charAt(i));
		}
		System.out.println("hai");

	}

}
