package com.demo;

public class Shape {
	private int l;
	private int b;

	Shape() {

	}

	Shape(int l, int b) {
		this.l = l;
		this.b = b;
	}

	void show_det() {
		System.out.println(l);
		System.out.println(b);
		
	}

}
