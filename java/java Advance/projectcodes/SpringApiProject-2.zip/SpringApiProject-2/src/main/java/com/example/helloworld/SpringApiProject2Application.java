package com.example.helloworld;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringApiProject2Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringApiProject2Application.class, args);
	}

}
